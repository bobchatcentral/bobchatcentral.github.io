DUNKIN LITE v4 - original-style tab bar app (iOS 5+, Xcode 4.6.3)

FOLDERS
  Classes/    all source code (.h/.m)  -> add every file to the project
  Resources/  app icons + tab bar icons -> add every file to the project

NEW PROJECT SETTINGS
  1. Xcode 4.6.3: File > New > Project > iOS > Application > Empty Application
     Name: DunkinWeb   Device Family: iPhone   Automatic Reference Counting: OFF
  2. Delete the template's AppDelegate.h/.m and main.m (Move to Trash).
  3. Drag in everything from Classes/ and Resources/ (tick "Copy items").
  4. Target > Summary: iOS Deployment Target = 5.0
     Build Settings: Architectures = armv7
  5. Target > Build Phases > Link Binary With Libraries: add
        CoreLocation.framework   MapKit.framework
  6. Info.plist: add "Icon files" (array): Icon.png, Icon@2x.png, Icon-Small.png, Icon-Small@2x.png
                 add "Icon already includes gloss effects" = YES
  7. Code signing: "Don't Code Sign" (or xcodebuild with CODE_SIGNING_REQUIRED=NO).
  8. Test first in the iOS Simulator (iPhone, 6.1), then install on the phone with scp + ldid -S + uicache.

TABS
  My Cards (SAMPLE cards only)  |  Menu  |  Restaurants  |  Gift  |  More

NOTES
  - Sample cards are always stamped SAMPLE - NOT A REAL CARD, have no barcode or number, and have no value.
  - Unofficial fan app. Not affiliated with Dunkin' Brands.
